# Ontogenesis — Human Digital Twin Ontology
Base IRI: `https://socioprophet.dev/ont/ontogenesis#`, Version IRI: `https://socioprophet.dev/ont/ontogenesis#v0.3.0`, Generated: 2025-08-28T22:28:24.218856Z

Contents: OWL (`ontogenesis.ttl`), SKOS (`skos/*.ttl`), SHACL (`shapes/*.ttl`), mappings, JSON-LD context, examples, tests, CapD.
