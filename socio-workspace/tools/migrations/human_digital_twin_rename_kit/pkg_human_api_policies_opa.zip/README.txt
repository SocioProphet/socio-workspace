Extract at repo root. This package targets: human_digital_twin/api/policies/opa
