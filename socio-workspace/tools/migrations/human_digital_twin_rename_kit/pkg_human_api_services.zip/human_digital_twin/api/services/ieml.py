"""IEML stub: encode core concepts with E,U,A,S,B,~T primitives.

This is a placeholder mapping; swap with a proper registry when ready.
"""
from typing import Dict

# naive dictionary to start; expand per intlekt.io spec
IEML_DICT: Dict[str, str] = {
    "Observation": "E.U",
    "Consent": "A.S",
    "Export": "B.T",
    "Linkage": "U.A",
}

def lookup(concept: str) -> str:
    return IEML_DICT.get(concept, "E")