"""Simple path-flow runner: exercises Evaluate/Promote over sample scenarios."""
import json, yaml, time
from pathlib import Path
try:
    from human_digital_twin.api.services.eval.omega
except Exception:
    from hdt_app_v1_0.api.services.eval.omega import EvalKFS, promote_omega

def run_scenario(name: str, steps=5):
    prev = "ABSENT"
    for k in range(steps):
        # toy scores; swap for real measurements
        kfs = EvalKFS(m_cbd=0.6+0.1*k, m_cgt=0.55+0.1*k, m_nhy=0.5+0.1*k)
        prev, meta = promote_omega(prev, kfs)
        if prev == "DELIVERED":
            return prev, k+1, meta
    return prev, steps, meta

if __name__ == "__main__":
    sc = list(yaml.safe_load(Path("tools/pathflows/examples.yaml").read_text()))
    out = {}
    for s in sc:
        omega, steps, meta = run_scenario(s["name"], s["expect"]["steps_max"])
        out[s["name"]] = {"omega": omega, "steps": steps, "meta": meta}
    Path("tools/pathflows/report.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))